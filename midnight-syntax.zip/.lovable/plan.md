## Midnight Coders — Website Build

A faithful recreation of the OwlCoder / Technical Hub layout, rebranded as **Midnight Coders**, carrying the light layout with green/yellow accents from the source. Content (course names, stats, testimonials) is reused, images are AI‑generated placeholders, and the brand identity ties in **Geeta University** and **Geeta Technical Hub**.

### Pages / Routes
```
/            Home (landing)
/courses     Course listing
/contact     Contact page
```

### Design System
- **Palette (light theme):** white/off-white background `#fcfbf8`, primary green `#159b41`, secondary lime `#7ac143`, accent yellow `#f5a623`, dark text `#1a1a2e`. Stat band uses a green→lime gradient.
- **Type:** distinctive bold display font for headings (Outfit) + clean body (Figtree), loaded via @fontsource.
- **Tokens** defined in `src/styles.css` (`@theme`), no hardcoded colors in components.
- Rounded cards, soft shadows, decorative dotted/shape accents echoing the source.

### Home page sections (top → bottom)
1. **Header** — Midnight Coders logo (with Geeta Technical Hub mark), nav (Home, Courses, Contact), Login button.
2. **Hero** — "TRAINED BY US, RECOGNIZED BY THE WORLD" headline, "Since 2016 / 60+ Tech Coaches" badge card, generated hero image of learners, decorative shapes.
3. **Stats bar** — green gradient band: 100+ Courses, Top Instructors, Global Certifications, 30000 Trainees (icons).
4. **Top Categories** — Technology Training, Coding, Apt logic, Communication, Profile Building, Placements, Certifications, Internships, Project Space.
5. **About** — "Learn & Grow with Geeta Technical Hub" + bullet points (Industry Standard Training, Global Certifications, 100% Placement Assistance), 50+ Certifications badge, generated images.
6. **Popular Courses** — cards: AWS Development, Google Flutter, FSD with React Native, Generative AI (weeks, level, modules, hours) + "Browse more courses" → /courses.
7. **Counters** — 30K Trainees, 10K+ Certifications, 50+ Courses, 100% Placement Assistance.
8. **Testimonials** — Rami Reddy, Sameera, Sankar cards.
9. **CTA** — "Get Your Quality Skills Certificate Through Geeta Technical Hub" + Get started → /contact.
10. **Partners** — "Working with the best" logo strip (generated placeholder marks).
11. **Footer** — Midnight Coders + Geeta University / Geeta Technical Hub branding, contact (support email, phone), quick links.

### Courses page
Grid of course cards (reusing the home course component) with filter chips by category, hero strip, and consistent header/footer.

### Contact page
Contact form (name, email, message — front-end only), contact details (email, phone), and a "Get in touch" section. Form shows a success toast on submit (no backend).

### Branding note
Logos for Midnight Coders, Geeta University, and Geeta Technical Hub will be AI‑generated wordmark/badge placeholders (clean, on-brand) since original brand assets can't be copied. If you have official logo files, you can upload them and I'll swap them in.

### Technical details
- TanStack Start file-based routes: `src/routes/index.tsx`, `courses.tsx`, `contact.tsx`; shared `Header`/`Footer` components in `src/components/`.
- Reusable components: `CourseCard`, `CategoryCard`, `StatItem`, `TestimonialCard`, `SectionHeading`.
- Per-route `head()` metadata (title, description, og tags); single H1 per page; semantic HTML; alt text on all images; responsive (mobile nav via Sheet).
- Images generated with the image tool into `src/assets/` and imported as ES modules.
- shadcn `button`, `card`, `input`, `textarea`, `sheet`, `sonner` reused.
- All static front-end; no database or auth unless you later want a working Login/contact backend.
